package com.example.george.frag;

/**
 * Created by george on 9/30/2017.
 */

public interface communicator {
    public void respond(int i);

}
