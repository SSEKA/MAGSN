package com.example.george.frag;

import android.app.Fragment;

/**
 * Created by george on 10/1/2017.
 */

public class FragmentC extends Fragment {
}
